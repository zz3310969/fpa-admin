import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux, Link } from 'dva/router';
import {
  Form, Input, DatePicker, Select, Button, Card, InputNumber, Radio, Icon, Tooltip,Row,Col,Table,Upload,Avatar 
} from 'antd';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import style from './CardUnit.less';
import ThemeTable from './ThemeTable'
import CardAttrEditModal from './CardAttrEditModal';
import ThemeTableModal from './ThemeTableModal';


const { Meta } = Card;
const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
const { TextArea } = Input;

@connect(state => ({
  cardgroup: state.cardgroup,
}))
@Form.create()



export default class BasicForms extends PureComponent {
  state = {
  };

  componentDidMount() {
    const { dispatch } = this.props;

  }

  settingHandle = ()=>{
    


  }
  attrOKHander = () =>{

  }
  editHandle = ()=>{
    

  }

  
  render(){
    const { colors, themes } = this.props;
    const { getFieldDecorator } = this.props.form;

    const self = this;
    const dataSource = [{
        key: '1',
        name: '胡彦斌',
        age: 32,
        address: '西湖区湖底公园1号'
      }, {
        key: '2',
        name: '胡彦祖',
        age: 42,
        address: '西湖区湖底公园1号'
      }, {
        key: '3',
        name: '胡彦祖',
        age: 42,
        address: '西湖区湖底公园1号'
      }, {
        key: '4',
        name: '胡彦祖',
        age: 42,
        address: '西湖区湖底公园1号'
      }, {
        key: '5',
        name: '胡彦祖',
        age: 42,
        address: '西湖区湖底公园1号'
      }, {
        key: '6',
        name: '胡彦祖',
        age: 42,
        address: '西湖区湖底公园1号'
      }
    ];

    const getCover = function(imageUrl){
      return (
        <Upload
          name="avatar"
          listType="picture-card"
          className="avatar-uploader"
          class={{width:'100%'}}
          showUploadList={false}
          action="//jsonplaceholder.typicode.com/posts/"
        >
          {imageUrl ? <img src={imageUrl} alt="" /> : uploadButton}
        </Upload>
        
      )
    }
          // beforeUpload={beforeUpload}
          // onChange={this.handleChange}
// <img alt="example" src="https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png" />
    const columns = [{
      title: '序号',

    },
          {
        title: '卡牌',
        width:'100%',
        children: [{
          title: '正面',
          dataIndex: 'front2',
          key: 'front2',
          render:function(text,index,record){
            let imageUrl = text;
            return (
              <Card
                style={{width:200}}
                cover={getCover("https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png")}
                actions={[
                  <ThemeTableModal><Icon type="setting" onClick={self.settingHandle} /></ThemeTableModal>, 
                  <CardAttrEditModal colors={colors} themes={themes}><Icon type="edit" onClick={self.editHandle} /></CardAttrEditModal>, 
                  <Icon type="ellipsis" />]}
              >
               
              </Card>
            );
          }
        }, {
          title: '反面',
          dataIndex: 'back2',
          key: 'back2',
          render:function(text,index,record){
            let imageUrl = text;
            return (
              <Card
                style={{width:200}}
                cover={getCover("https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png")}
                actions={[
                  <ThemeTableModal><Icon type="setting" onClick={self.settingHandle} /></ThemeTableModal>, 
                  <CardAttrEditModal colors={colors} themes={themes}><Icon type="edit" onClick={self.editHandle} /></CardAttrEditModal>, 
                  <Icon type="ellipsis" />]}
              >
              </Card>
            );
          }
        }]
      }
    ];

    return (
      <Table
        bordered={true}
        dataSource={dataSource}
        style={{width:'100%'}}
        className="card-unit-table"
        columns={columns}
        pagination={false}
      />
    )
  }
}
